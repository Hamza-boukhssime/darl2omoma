// import axios from 'axios'
import { Route, Routes } from 'react-router-dom'
import AddPatient from '../Pages/AddPatient'
import Dashboard from '../Pages/Dashboard'
import Pregnant from '../Pages/Pregnant'
import Search from '../Pages/Search'
import SpecialVisit from '../Pages/SpecialVisit'
import WithBaby from '../Pages/WithBaby'

import Print from '../Pages/Prints/Print'
import PrintBaby from '../Pages/Prints/PrintBaby'
import PrintSpecial from '../Pages/Prints/PrintSpecial'


function Content() {
  return (
    <div className='col-md-10 p-0 m-0 bg-light ' >
      <Routes>
        <Route path='/' element={<Dashboard class='activelink' />} />
        <Route path='/add' element={<AddPatient class='activelink'  />} />
        <Route path='/add/pregnant' element={<Pregnant class='activelink'  />} />
        <Route path='/add/specialVisit' element={<SpecialVisit />} />
        <Route path='/add/baby' element={<WithBaby />} />
        <Route path='/print/pregnant/:id' element={<Print />} />
        <Route path='/print/withbaby/:id' element={<PrintBaby />} />
        <Route path='/print/specialvisit/:id' element={<PrintSpecial />} />
        <Route path='/search' element={<Search />} />

      </Routes>
    </div>
  )
}

export default Content